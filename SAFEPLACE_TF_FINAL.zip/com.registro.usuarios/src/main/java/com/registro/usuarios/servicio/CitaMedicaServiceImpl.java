package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.CitaMedica;
import com.registro.usuarios.repositorio.ICitaMedicaRepository;



@Service
public class CitaMedicaServiceImpl implements ICitaMedicaService {

	@Autowired
	private ICitaMedicaRepository citamedicaRepository;

	@Override
	public void insert(CitaMedica citamedica) {
		// TODO Auto-generated method stub
		citamedicaRepository.save(citamedica);
	}

	@Override
	public List<CitaMedica> list() {
		// TODO Auto-generated method stub
		return citamedicaRepository.findAll();
	}

	@Override
	public void delete(int idCitaMedica) {
		// TODO Auto-generated method stub
		citamedicaRepository.deleteById(idCitaMedica);
	}

	@Override
	public Optional<CitaMedica> listId(int idCitaMedica) {
		// TODO Auto-generated method stub
		return citamedicaRepository.findById(idCitaMedica);
	}

	@Override
	public void updateCitaMedica(CitaMedica citamedica) {
		// TODO Auto-generated method stub
		citamedicaRepository.save(citamedica);
	}


}
