package com.registro.usuarios.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "TipoServicio")
public class TipoServicio {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTipoServicio;

	@NotEmpty(message = "Digite el tipo de servicio")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "nameServicio", nullable = false)
	private String nameServicio;

	@ManyToOne
	@JoinColumn(name = "idTipoPago", nullable = false)
	private TipoPago tipopago;

	public TipoServicio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TipoServicio(int idTipoServicio, String nameServicio, TipoPago tipopago) {
		super();
		this.idTipoServicio = idTipoServicio;
		this.nameServicio = nameServicio;
		this.tipopago = tipopago;
	}

	public int getIdTipoServicio() {
		return idTipoServicio;
	}

	public void setIdTipoServicio(int idTipoServicio) {
		this.idTipoServicio = idTipoServicio;
	}

	public String getNameServicio() {
		return nameServicio;
	}

	public void setNameServicio(String nameServicio) {
		this.nameServicio = nameServicio;
	}

	public TipoPago getTipopago() {
		return tipopago;
	}

	public void setTipopago(TipoPago tipopago) {
		this.tipopago = tipopago;
	}

}