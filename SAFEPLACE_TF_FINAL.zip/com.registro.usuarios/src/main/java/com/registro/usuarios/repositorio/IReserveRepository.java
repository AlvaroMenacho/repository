package com.registro.usuarios.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.Reserve;



@Repository
public interface IReserveRepository extends JpaRepository<Reserve, Integer> {

	@Query ("SELECT p from Reserve p WHERE p.tipoEntrega LIKE %?1%")
	public List<Reserve> findAll(String palabraclave);
}
