package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import com.registro.usuarios.modelo.TipoPago;
import com.registro.usuarios.servicio.ITipoPagoService;

@Controller
@RequestMapping("/tpagos")
public class TipoPagoController {
	@Autowired
	ITipoPagoService tpService;

	@GetMapping("/nuevo")
	public String newTipoPago(Model model) {
		model.addAttribute("tipoPago", new TipoPago());
		return "tipopago/frmRegistro";
	}

	@PostMapping("/guardar")
	public String saveTipoPago(@Valid TipoPago tipoPago, BindingResult binRes, Model model, SessionStatus status)
			throws Exception {
		if (binRes.hasErrors()) {
			return "tipopago/frmRegistro";
		} else {
			tpService.insert(tipoPago);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			status.setComplete();
			return "redirect:/tpagos/nuevo";
		}
	}

	@GetMapping("/listar")
	public String listTipoPago(Model model,@Param("palabraClave") String palabraClave) {
		try {
			model.addAttribute("tipoPago", new TipoPago());
			model.addAttribute("listaTPagos", tpService.listAll(palabraClave));
			model.addAttribute("palabraClave", palabraClave);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/tipopago/frmLista";
	}

	@RequestMapping("/eliminar")
	public String deleteTipoPago(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				tpService.delete(id);
				model.put("listaTPagos", tpService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "tipopago/frmLista";
	}

	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<TipoPago> objtp = tpService.listId(id);
		model.addAttribute("tps", objtp.get());
		return "tipopago/frmActualiza";
	}

	@PostMapping("/modificarTp")
	public String updateTipoPago(TipoPago pag) {
		tpService.updateTipoPago(pag);
		return "redirect:/tpagos/listar";
	}
	
	@RequestMapping("/reporte")
	public String tipopagomasUsado(Map<String,Object>model) {
		model.put("reporteListapagos", tpService.tipopagomasUsado());
		return "tipopago/vista";
	}
}
