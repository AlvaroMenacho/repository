package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.Reserve;
import com.registro.usuarios.repositorio.IReserveRepository;



@Service
public class ReserveServiceImpl implements IReserveService {

	@Autowired
	private IReserveRepository reserveRepository;

	@Override
	public void insert(Reserve reserve) {
		reserveRepository.save(reserve);
	}

	@Override
	public List<Reserve> list() {
		return reserveRepository.findAll();
	}

	@Override
	public void delete(int idPerson) {
		reserveRepository.deleteById(idPerson);
	}

	@Override
	public Optional<Reserve> listId(int idReserve) {
		return reserveRepository.findById(idReserve);
	}

	@Override
	public void update(Reserve reserve) {
		reserveRepository.save(reserve);
	}

	@Override
	public List<Reserve> listAll(String palabraClave) {
		if(palabraClave != null) {
			return reserveRepository.findAll(palabraClave);
		}
		return reserveRepository.findAll();
	}

}
