package com.registro.usuarios.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "TipoPago")
public class TipoPago {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idTPago;

	@NotEmpty(message = "Digite el tipo de pago")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "namepago", nullable = false)
	private String namepago;

	public TipoPago() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TipoPago(int idTPago, String namepago) {
		super();
		this.idTPago = idTPago;
		this.namepago = namepago;
	}

	public int getIdTPago() {
		return idTPago;
	}

	public void setIdTPago(int idTPago) {
		this.idTPago = idTPago;
	}

	public String getNamepago() {
		return namepago;
	}

	public void setNamepago(String namepago) {
		this.namepago = namepago;
	}

}
