package com.registro.usuarios.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.TipoServicio;


@Repository
public interface ITipoServicioRepository extends JpaRepository<TipoServicio,Integer>{

	
	@Query ("SELECT p from TipoServicio p WHERE p.nameServicio LIKE %?1%")
	public List<TipoServicio> findAll(String palabraclave);
}
