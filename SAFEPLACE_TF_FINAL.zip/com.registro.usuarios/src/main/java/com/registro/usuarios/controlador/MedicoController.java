package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import com.registro.usuarios.modelo.Medico;
import com.registro.usuarios.servicio.IMedicoService;

@Controller
@RequestMapping("/medicos")
public class MedicoController {

	@Autowired
	private IMedicoService medService;

	@GetMapping("/nuevomedico")
	public String newMedico(Model model) {
		model.addAttribute("medico", new Medico());
		return "medico/frmRegistroMedico";
	}

	@PostMapping("/guardarMedico")
	public String saveMedico(@Valid Medico medico, BindingResult binRes, Model model, SessionStatus status)
			throws Exception {
		if (binRes.hasErrors()) {
			return "medico/frmRegistroMedico";
		} else {
			medService.insert(medico);
			model.addAttribute("mensaje", "Se registró correctamente!!");
			return "redirect:/medicos/nuevomedico";
		}

	}

	@GetMapping("/listarmedico")
	public String listMedico(Model model, @Param("palabraClave") String palabraClave) {
		try {
			model.addAttribute("medico", new Medico());
			model.addAttribute("listaMedicos", medService.listAll(palabraClave));
			model.addAttribute("palabraClave", palabraClave);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/medico/frmListaMedicos";
	}

	@RequestMapping("/eliminarMedico")
	public String deleteMedico(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				medService.delete(id);
				model.put("listaMedicos", medService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "medico/frmListaMedicos";
	}

	@RequestMapping("/irmodificarmedico/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<Medico> objMed = medService.listId(id);
		model.addAttribute("medi", objMed.get());
		return "medico/frmActualizaMedico";
	}

	@PostMapping("/modificarMedico")
	public String updateMedico(Medico me) {
		medService.updateMedico(me);
		return "redirect:/medicos/listarmedico";
	}

	@RequestMapping("/reporte")
	public String citamedicaMedico(Map<String, Object> model) {
		model.put("reporteListacitas", medService.citamedicaMedico());
		return "medico/vista";
	}

}
