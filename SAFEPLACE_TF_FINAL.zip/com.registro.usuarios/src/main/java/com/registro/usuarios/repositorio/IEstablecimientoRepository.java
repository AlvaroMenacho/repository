package com.registro.usuarios.repositorio;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



import com.registro.usuarios.modelo.Establecimiento;

@Repository
public interface IEstablecimientoRepository extends JpaRepository<Establecimiento, Integer> {


	@Query(value = "Select e.name_establecimiento,Count(e.name_establecimiento) \r\n"
			+ "From establecimiento e,reserve r\r\n"
			+ "where e.id_establecimiento=r.id_establecimiento \r\n"
			+ "group by name_establecimiento", nativeQuery = true)
	public List<String[]> reservaEstablecimiento();
	
	
	@Query(value = "select name_establecimiento,name_servicio,Count(name_servicio)\r\n"
			+ "from establecimiento e,tipo_servicio ts,reserve r\r\n"
			+ "where ts.id_tipo_servicio =e.id_tipo_servicio and \r\n"
			+ "e.id_establecimiento=r.id_establecimiento\r\n"
			+ "group by name_establecimiento,name_servicio\r\n"
			+ "order by 1,3 desc", nativeQuery = true)
	public List<String[]> servicioEstablecimiento();
	
	@Query("SELECT p from Establecimiento p WHERE p.adressEstablecimiento LIKE %?1%"
			+"OR p.nameEstablecimiento LIKE %?1%")
	public List<Establecimiento> findAll(String palabraclave);
}
