package com.registro.usuarios.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

import com.registro.usuarios.modelo.TipoPago;


@Repository
public interface ITipoPagoRepository extends JpaRepository<TipoPago,Integer>{

	@Query(value = "select namepago,Count(namepago)\r\n"
			+ "from tipo_pago tp,tipo_servicio ts,establecimiento e ,reserve r\r\n"
			+ "where tp.idtpago=ts.id_tipo_pago and\r\n"
			+ "ts.id_tipo_servicio=e.id_tipo_servicio and\r\n"
			+ "e.id_establecimiento=r.id_establecimiento\r\n"
			+ "group by namepago", nativeQuery = true)
	public List<String[]> tipopagomasUsado();
	
	
	@Query ("SELECT p from TipoPago p WHERE p.namepago LIKE %?1%")
	public List<TipoPago> findAll(String palabraclave);
}
