package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.Establecimiento;



public interface IEstablecimientoService {
	public void insert(Establecimiento establecimiento);

	public List<Establecimiento> list();

	public void delete(int idEstablecimiento);

	Optional<Establecimiento> listId(int idEstablecimiento);

	public void updateEstablecimiento(Establecimiento establecimiento);
	
	public List<String[]>reservaEstablecimiento();
	public List<String[]> servicioEstablecimiento();
	
	public List<Establecimiento> listAll(String palabraClave);
}
