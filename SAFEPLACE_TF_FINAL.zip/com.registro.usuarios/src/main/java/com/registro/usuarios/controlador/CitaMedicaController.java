package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.registro.usuarios.modelo.CitaMedica;
import com.registro.usuarios.servicio.ICitaMedicaService;
import com.registro.usuarios.servicio.IMedicoService;
import com.registro.usuarios.servicio.IReserveService;



@Controller
@RequestMapping("/citamedicas")
public class CitaMedicaController {

	@Autowired
	private IMedicoService mService;
	@Autowired
	private IReserveService rService;
	@Autowired
	private ICitaMedicaService cService;
	
	
	@GetMapping("/nuevo")
	public String newCitaMedica(Model model) {
		model.addAttribute("p", new CitaMedica());
		model.addAttribute("listaMedicos", mService.list());
		model.addAttribute("listaReservas", rService.list());
		return "citamedica/frmRegistro";
	}

	@PostMapping("/guardar")
	public String saveCitaMedica(@Validated CitaMedica cit, BindingResult binRes) {
		if (binRes.hasErrors()) {
			return "citamedica/frmRegistro";
		} else {
			cService.insert(cit);
			return "redirect:/citamedicas/nuevo";
		}

	}
	@GetMapping("/listar")
	public String listCitaMedica(Model model,@Param("palabraClave") String palabraClave) {
		try {
			model.addAttribute("CitaMedica", new CitaMedica());
			model.addAttribute("listaCitaMedicas", cService.list());
			model.addAttribute("palabraClave", palabraClave);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/citamedica/frmLista";
	}

	@RequestMapping("/eliminar")
	public String deleteCitaMedica(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				cService.delete(id);
				model.put("listaCitaMedicas", cService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "citamedica/frmLista";
	}
	
	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<CitaMedica> objCit = cService.listId(id);
		model.addAttribute("cits", objCit.get());
		model.addAttribute("listaMedicos", mService.list());
		model.addAttribute("listaReservas", rService.list());
		return "citamedica/frmActualiza";
	}

	@PostMapping("/modificar")
	public String updateCitaMedica(CitaMedica c) {
		cService.updateCitaMedica(c);
		return "redirect:/citamedicas/listar";
	}
}
