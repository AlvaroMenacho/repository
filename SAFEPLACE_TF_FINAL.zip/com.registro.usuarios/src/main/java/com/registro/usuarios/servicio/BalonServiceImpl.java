package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registro.usuarios.modelo.Balon;
import com.registro.usuarios.repositorio.IBalonRepository;


@Service
public class BalonServiceImpl implements IBalonService {

	@Autowired
	private IBalonRepository balonRepository;
	
	
	@Override
	public void insert(Balon balon) {
		// TODO Auto-generated method stub
		balonRepository.save(balon);
	}

	@Override
	public List<Balon> list() {
		// TODO Auto-generated method stub
		return balonRepository.findAll();
	}

	@Override
	public void delete(int idBalon) {
		// TODO Auto-generated method stub
		balonRepository.deleteById(idBalon);
	}

	@Override
	public Optional<Balon> listId(int idBalon) {
		// TODO Auto-generated method stub
		return balonRepository.findById(idBalon);
	}

	@Override
	public void updateBalon(Balon balon) {
		
		balonRepository.save(balon);
	}

	@Override
	public List<Balon> listAll(String palabraClave) {
		if(palabraClave != null) {
			return balonRepository.finAll(palabraClave);
		}
		return balonRepository.findAll();
	}

	

}
