package com.registro.usuarios.modelo;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "CitaMedica")
public class CitaMedica {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idCita;
	
	@ManyToOne
	@JoinColumn(name = "idMedico")
	private Medico medico;
	
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@ManyToOne
	@JoinColumn(name = "idReserva")
	private Reserve reserva;

	public CitaMedica() {
		super();
		//TODO Auto-generated constructor stub
	}

	public CitaMedica(int idCita, Medico medico, Reserve reserva) {
		super();
		this.idCita = idCita;
		this.medico = medico;
		this.reserva = reserva;
	}

	public int getIdCita() {
		return idCita;
	}

	public void setIdCita(int idCita) {
		this.idCita = idCita;
	}

	public Medico getMedico() {
		return medico;
	}

	public void setMedico(Medico medico) {
		this.medico = medico;
	}

	public Reserve getReserva() {
		return reserva;
	}

	public void setReserva(Reserve reserva) {
		this.reserva = reserva;
	}
	
	
}
