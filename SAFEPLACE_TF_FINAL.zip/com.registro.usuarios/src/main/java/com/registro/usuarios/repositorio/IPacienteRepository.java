package com.registro.usuarios.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.registro.usuarios.modelo.Paciente;

@Repository
public interface IPacienteRepository extends JpaRepository<Paciente, Integer> {

	@Query("SELECT p from Paciente p WHERE p.fullNamePaciente LIKE %?1%"
			+ "OR p.phonePaciente LIKE %?1%")
	public List<Paciente> findAll(String palabraclave);
}
