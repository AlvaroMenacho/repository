package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.Paciente;


public interface IPacienteService {

	public void insert(Paciente paciente);

	public List<Paciente> list();

	public void delete(int idPaciente);

	Optional<Paciente> listId(int idPaciente);

	public void updatePaciente(Paciente paciente);
	
	public List<Paciente> listAll(String palabraClave);
}
