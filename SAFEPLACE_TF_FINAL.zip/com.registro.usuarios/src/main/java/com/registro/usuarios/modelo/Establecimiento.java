package com.registro.usuarios.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "Establecimiento")
public class Establecimiento {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idEstablecimiento;

	@NotEmpty(message = "Digite su dirección")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "adressEstablecimiento", nullable = false)
	private String adressEstablecimiento;

	@NotEmpty(message = "Digite su nombre de establecimiento")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "nameEstablecimiento", nullable = false)
	private String nameEstablecimiento;

	@ManyToOne
	@JoinColumn(name = "idTipoServicio")
	private TipoServicio tiposervicio;

	public Establecimiento() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Establecimiento(int idEstablecimiento, String adressEstablecimiento, String nameEstablecimiento,
			TipoServicio tiposervicio) {
		super();
		this.idEstablecimiento = idEstablecimiento;
		this.adressEstablecimiento = adressEstablecimiento;
		this.nameEstablecimiento = nameEstablecimiento;
		this.tiposervicio = tiposervicio;
	}

	public int getIdEstablecimiento() {
		return idEstablecimiento;
	}

	public void setIdEstablecimiento(int idEstablecimiento) {
		this.idEstablecimiento = idEstablecimiento;
	}

	public String getAdressEstablecimiento() {
		return adressEstablecimiento;
	}

	public void setAdressEstablecimiento(String adressEstablecimiento) {
		this.adressEstablecimiento = adressEstablecimiento;
	}

	public String getNameEstablecimiento() {
		return nameEstablecimiento;
	}

	public void setNameEstablecimiento(String nameEstablecimiento) {
		this.nameEstablecimiento = nameEstablecimiento;
	}

	public TipoServicio getTiposervicio() {
		return tiposervicio;
	}

	public void setTiposervicio(TipoServicio tiposervicio) {
		this.tiposervicio = tiposervicio;
	}

}
