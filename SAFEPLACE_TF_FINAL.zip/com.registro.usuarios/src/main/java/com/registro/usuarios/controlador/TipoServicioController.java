package com.registro.usuarios.controlador;

import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;

import com.registro.usuarios.modelo.TipoServicio;
import com.registro.usuarios.servicio.ITipoPagoService;
import com.registro.usuarios.servicio.ITipoServicioService;

@Controller
@RequestMapping("/tiposervicios")
public class TipoServicioController {

	@Autowired
	private ITipoPagoService tpService;

	@Autowired
	private ITipoServicioService tsService;

	@GetMapping("/nuevo")
	public String newTipoServicio(Model model) {
		model.addAttribute("tipoServicio", new TipoServicio());
		model.addAttribute("listaTipoPagos", tpService.list());
		return "tiposervicio/frmRegistro";
	}

	@PostMapping("/guardar")
	public String saveTipoServicio(@Valid TipoServicio tipoServicio, BindingResult binRes, Model model,
			SessionStatus status) throws Exception {
		if (binRes.hasErrors()) {
			model.addAttribute("listaTipoPagos", tpService.list());
			return "tiposervicio/frmRegistro";
		} else {
			tsService.insert(tipoServicio);
			return "redirect:/tiposervicios/nuevo";
		}

	}

	@GetMapping("/listar")
	public String listServicio(Model model, @Param("palabraClave") String palabraClave) {
		try {
			model.addAttribute("tipoServicio", new TipoServicio());
			model.addAttribute("listaServicios", tsService.listAll(palabraClave));
			model.addAttribute("palabraClave", palabraClave);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
		}

		return "/tiposervicio/frmLista";
	}

	@RequestMapping("/eliminar")
	public String deleteTipoServicio(Map<String, Object> model, @RequestParam(value = "id") Integer id) {

		try {
			if (id != null && id > 0) {
				tsService.delete(id);
				model.put("listaServicios", tsService.list());
			}

		} catch (Exception e) {
			model.put("error", e.getMessage());
		}
		return "tiposervicio/frmLista";
	}

	@RequestMapping("/irmodificar/{id}")
	public String goUpdate(@PathVariable int id, Model model) {
		Optional<TipoServicio> objTs = tsService.listId(id);
		model.addAttribute("tss", objTs.get());
		model.addAttribute("listaTipoPagos", tpService.list());
		return "tiposervicio/frmActualiza";
	}

	@PostMapping("/modificar")
	public String updateTipoServicio(TipoServicio t) {
		tsService.updateTipoServicio(t);
		return "redirect:/tiposervicios/listar";
	}

}
