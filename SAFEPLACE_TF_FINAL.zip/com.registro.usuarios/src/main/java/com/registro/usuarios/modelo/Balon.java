package com.registro.usuarios.modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

@Entity
@Table(name = "Balon")
public class Balon {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idBalon;

	@NotEmpty(message = "Digite el tipo de balón")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "toxigeno", nullable = false)
	private String toxigeno;

	@Positive(message = "Debe ser positivo")
	@Column(name = "capacidad", nullable = false)
	private double capacidad;

	@Positive(message = "Debe ser positivo")
	@Column(name = "peso", nullable = false)
	private double peso;

	@Positive(message = "Debe ser positivo")
	@Column(name = "precio", nullable = false)
	private double precio;

	@ManyToOne
	@JoinColumn(name = "idEstablecimiento")
	private Establecimiento establecimiento;

	public Balon() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Balon(int idBalon, String toxigeno, double capacidad, double peso, double precio,
			Establecimiento establecimiento) {
		super();
		this.idBalon = idBalon;
		this.toxigeno = toxigeno;
		this.capacidad = capacidad;
		this.peso = peso;
		this.precio = precio;
		this.establecimiento = establecimiento;
	}

	public int getIdBalon() {
		return idBalon;
	}

	public void setIdBalon(int idBalon) {
		this.idBalon = idBalon;
	}

	public String getToxigeno() {
		return toxigeno;
	}

	public void setToxigeno(String toxigeno) {
		this.toxigeno = toxigeno;
	}

	public double getCapacidad() {
		return capacidad;
	}

	public void setCapacidad(double capacidad) {
		this.capacidad = capacidad;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Establecimiento getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(Establecimiento establecimiento) {
		this.establecimiento = establecimiento;
	}

}