package com.registro.usuarios.modelo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "Paciente")
public class Paciente {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int idPaciente;

	@NotEmpty(message = "Digite su nombre")
	@NotBlank(message = "No debe estar vacío")
	@Column(name = "fullNamePaciente", nullable = false)
	private String fullNamePaciente;

	@Past(message = "Debe ser una fecha anterior")
	@NotNull(message = "Seleccione fecha")
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "birthDatePaciente", nullable = false)
	private Date birthDatePaciente;

	@NotEmpty(message = "Digite el número de celular")
	@NotBlank(message = "No debe estar vacío")
	@Size(min = 9, max = 9, message = "Deben ser 9 números")
	@Column(name = "phonePaciente", nullable = false)
	private String phonePaciente;

	public Paciente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Paciente(int idPaciente, String fullNamePaciente, Date birthDatePaciente, String phonePaciente) {
		super();
		this.idPaciente = idPaciente;
		this.fullNamePaciente = fullNamePaciente;
		this.birthDatePaciente = birthDatePaciente;
		this.phonePaciente = phonePaciente;
	}

	public int getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(int idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getFullNamePaciente() {
		return fullNamePaciente;
	}

	public void setFullNamePaciente(String fullNamePaciente) {
		this.fullNamePaciente = fullNamePaciente;
	}

	public Date getBirthDatePaciente() {
		return birthDatePaciente;
	}

	public void setBirthDatePaciente(Date birthDatePaciente) {
		this.birthDatePaciente = birthDatePaciente;
	}

	public String getPhonePaciente() {
		return phonePaciente;
	}

	public void setPhonePaciente(String phonePaciente) {
		this.phonePaciente = phonePaciente;
	}

}
