package com.registro.usuarios.servicio;

import java.util.List;
import java.util.Optional;

import com.registro.usuarios.modelo.Reserve;



public interface IReserveService {

	public void insert(Reserve reserve);

	public List<Reserve> list();

	public void delete(int idPerson);

	Optional<Reserve> listId(int idReserve);

	public void update(Reserve reserve);
	
	public List<Reserve> listAll (String palabraClave);
}
